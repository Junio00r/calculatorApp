package com.devmobile.android.calculadora.model.interfaces;

public interface EntradaDados {
    void inserirEntrada(String entrada);
}
