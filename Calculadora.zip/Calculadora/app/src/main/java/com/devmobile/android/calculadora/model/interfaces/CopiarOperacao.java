package com.devmobile.android.calculadora.model.interfaces;

public interface CopiarOperacao {

    void copiarOperacao();

}