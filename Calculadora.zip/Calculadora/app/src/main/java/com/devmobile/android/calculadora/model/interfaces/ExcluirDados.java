package com.devmobile.android.calculadora.model.interfaces;

public interface ExcluirDados {

    void excluirCaractere();
    void excluirTodaEntrada();
}
