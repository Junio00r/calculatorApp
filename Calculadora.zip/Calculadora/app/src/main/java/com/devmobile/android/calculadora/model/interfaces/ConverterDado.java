package com.devmobile.android.calculadora.model.interfaces;

public interface ConverterDado {

    double converterDado();

}